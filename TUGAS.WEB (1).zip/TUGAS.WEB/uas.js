function tambahkankekeranjang(namaProduk) {
  alert(namaProdukk + " telah ditambahkan ke keranjang!");
}
